/*
====================================================================================================================================
Name: 24.c
Author : KAUTILYA SINGH
Description : 
    Write a program to create a message queue and print the key and message queue id.
====================================================================================================================================
*/

#include<stdio.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<sys/msg.h>

int main(){
	
	key_t key, key2;
	int msgid, msgid2;

	key = ftok("msgqprog", 65);
	key2 = ftok("02.c", 66);

	if(key == -1){
		perror("ftok");
		exit(EXIT_FAILURE);
	}
	
	//create message queue and get the ID
	msgid = msgget(key, IPC_CREAT | 0666);
	msgid2 = msgget(key2, IPC_CREAT | 0666);

	if(msgid == -1){
		perror("msgget");
		exit(EXIT_FAILURE);
	}

	printf("key: %ld\n", (long)key);
	printf("Key in hex: 0x%0x\n", key);
	printf("Message queue ID: %d\n", msgid);
	
	printf("key2: %ld\n", (long)key2);
	printf("Key2 in hex: 0x%0x\n", key2);
	printf("Message queue ID: %d\n", msgid2);


	return 0;
}

/*
Output:

Kautilya-Singh:./24
key: 1091043596
Key in hex: 0x4108010c
Message queue ID: 0
key2: 1107823808
Key2 in hex: 0x42080cc0
Message queue ID: 2

*/

